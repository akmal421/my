<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	function __construct(){
		parent::__construct();

		$this->load->helper('form','url','file');


		$this->load->model(array('model'));
	}

	public function index()
	{
		$data['judul']='Tampil Data Balita';
		$data['Data']=$this->model->TampilSemuaData();
		$this->load->view('vpegawai',$data);
	}


	public function form_input()
	{
		$this->load->view('form_input');

	}
	public function delete_users($id)
	{
		$data = $this->model->ambil_id_gambar($id);
  // lokasi gambar berada
		$path = './image/';
  @unlink($path.$data->FOTO);// hapus data di folder dimana data tersimpan
  if ($this->model->delete_users($id) == TRUE) {
    // TAMPILKAN PESAN JIKA BERHASIL
  	$this->session->set_flashdata('pesan', 'DATA BERHASIL DI HAPUS');
  }
  echo "<script>alert('Data berhasil di hapus!');window.location='".base_url()."Welcome/index';</script>";
}

function aksi(){
	$this->form_validation->set_rules('nama','Nama','required');
	$this->form_validation->set_rules('email','Email','required|valid_email');
	$this->form_validation->set_rules('password','Password','required');
	$this->form_validation->set_rules('gender','Gender','required');
	$this->form_validation->set_rules('no','no','required');

	$this->form_validation->set_rules('userfile','Photo','required');
	$this->form_validation->set_rules('pekerjaan','pekerjaan','required');
   $this->form_validation->set_rules('password','Password','required|min_length[5]'); // min_length[5] password tidak boleh kurang dari lima
      $this->form_validation->set_rules('retypepassword','Retype Password','required|min_length[5]|matches[password]'); // matches[password] mencocokan password
      
      if($this->form_validation->run() != false){
      	$malnmfile = $this->input->post('nama');
      	$config['upload_path']		= 'image/';
      	$config['allowed_types']	= 'jpg|png';
		// $config['max_size']			= '2048';
		// $config['max_height']		= '768';
		// $config['max_width']		= '1288';
      	$config['file_name']		= $malnmfile;

      	$this->upload->initialize($config);
		//$this->load->library('upload', $config);
      	if(! $this->upload->do_upload())
      	{
					// $a=$this->upload->display_errors();
      		$a=$this->upload->display_errors();
      		echo $a;
      	}
      	else
      	{

      		$email =$this->input->post('email');
      		$password =$this->input->post('password');

      		$nama =$this->input->post('nama');

      		$gender =$this->input->post('gender');

      		$no =$this->input->post('no');

      		$pekerjaan = $this->input->post('pekerjaan');



      		$gbr=$this->upload->data();
      		$FOTO=$gbr['file_name'];
      		$this->model->fill_data($FOTO);
      		if($this->model->insert_data())
      		{

      			echo "<script>alert('Data berhasil di tambahkan!');window.location='".base_url()."Welcome/index';</script>";
						// $this->load->view('template',$data);
      		}



      	}
      }else{
      	$this->load->view('form_input');
      }
  }

}
