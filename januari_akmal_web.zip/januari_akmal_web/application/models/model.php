<?php

Class model extends CI_Model
{
	var $CI;
	
	
		function __construct()//method ini untuk ap??nama method saa,a dengan nama cclass,untuk mengambil method Bagianmodel,dan agar semua method bisa terbaca
		{
			parent::__construct();
			$this->CI =& get_instance();

		}
		
		function TampilSemuaData(){
			$hasil=$this->db->get('tbpegawai');
			return $hasil->result();
		}

		function fill_data($FOTO)
		{
			$this->data = array(
				
					// 'KDPELANGGAN'	=>$this->input->post('KDPELANGGAN'),
				'Email'	=>$this->input->post('email'),
				'Password'	=>$this->input->post('password'),
				'Nama'	=>$this->input->post('nama'),
				'Gender'	=>$this->input->post('gender'),
				'No_Telepon'	=>$this->input->post('no'),
				'Pekerjaan'	=>$this->input->post('pekerjaan'),
				'Photo ' =>$FOTO
				);
		}
		function insert_data(){
			$insert = $this->db->insert('tbpegawai', $this->data);
			return $insert;
		}

		public function delete_users($id){
			$this->db->where('id', $id);
			$this->db->delete('tbpegawai');
			return TRUE;
		}

		public function ambil_id_gambar($id)
		{
			$this->db->from('tbpegawai');
			$this->db->where('id', $id);
			$result = $this->db->get('');
   // periksa ada datanya atau tidak
			if ($result->num_rows() > 0) {
     return $result->row();//ambil datanya berdasrka row id
 }
 
}

}





