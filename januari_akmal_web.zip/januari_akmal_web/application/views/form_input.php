<!DOCTYPE html>
<html>
<head>
	<title>form registrasi</title>
</head>
<body>
	<h1>Registrasi User</h1>
<form method="post" action="<?php echo base_url().'Welcome/aksi' ;?>" enctype="multipart/form-data" method="post">
		<table>
			<?php echo validation_errors(); ?>
	
			<tr>
				<td>Email  :</td>

				<td><input type="email" name="email" placeholder="masukan email anda"></td>
				<?php echo form_error('email'); ?>
			</tr>
			<tr>
				<td>Password :</td>
				<td><input type="password" name="password" placeholder="masukan Password anda"></td>
			</tr>
			<tr>
				<td>Rytpe Password :</td>
				<td><input type="txtConfirmPassword" placeholder="masukan kembali Password"></td>
			</tr>
			<tr>
				<td>Nama :</td>
				<td><input type="text" name="nama" placeholder="masukan Nama anda"></td>
			</tr>
			<tr>
				<td>Gender :</td>
				<td>
					<input type="radio" name="gender" value="Laki-Laki" >Laki-Laki</input>
					<input type="radio" name="gender" value="Perempuan" >Perempuan</input>
				</td>
			</tr>
			<tr>
				<td>No telephone :</td>
				<td><input type="number" name="no" placeholder="masukan No telephone anda"></td>
			</tr>
			<tr>
				<td>Pekerjaan :</td>
				<td>
					<select name="pekerjaan">
						<option>Pilih Pekerjaan</option>
						<option value="Karyawan swasta">Karyawan swasta</option>
						<option value="Kristen">Pegawai negri</option>
						<option value="Belum bekerja">Belum bekerja</option>

					</select>

				</td>
			</tr>
				<tr>
					<td>Photo :</td>
					<td><input type="file" name="userfile" ></td>
				</tr>

		</table>
		<input type="submit" id="btnSubmit" value="kirim"></input>
	</form>


	 <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script type="text/javascript">
        $(function () {
            $("#btnSubmit").click(function () {
                var password = $("#password").val();
                var confirmPassword = $("#txtConfirmPassword").val();
                if (password != confirmPassword) {
                    alert("Passwords do not match.");
                    return false;
                }
                return true;
            });
        });
    </script>
</body>
</html>