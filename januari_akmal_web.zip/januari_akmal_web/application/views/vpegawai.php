<!DOCTYPE html>
<html>
<head>
	<title>january akmal web</title>
</head>
<body>
	<h1>USER LIST</h1>
	<table border="1">
		<thead>

			<th>No</th>
			<th>Email</th>
			<th>Password</th>
			<th>Nama</th>
			<th>Gender</th>
			<th>No_Telepon</th>
			<th>Pekerjaan</th>
			<th>Photo</th>
			<th>Action</th>
		</thead>
		<tbody>

			<?php
			if($Data){
				$i=1;
				foreach ($Data as $key) {
					echo "<tr>";
					echo "<td>".$i."</td>";
					echo "	<td>".$key->Email."</td>";
					echo "	<td>".$key->Password."</td>";
					echo "	<td>".$key->Nama."</td>";
					echo "	<td>".$key->Gender."</td>";
					echo "	<td>".$key->No_Telepon."</td>";
					echo "	<td>".$key->Pekerjaan."</td>";

					echo "<td><img src='".base_url()."/image/".$key->Photo."' width='100px' height='100px' alt=''></td>";
					echo "<td>";
					echo anchor(base_url().'Welcome/delete_users/'.$key->id, 'Delete', array('class'=>'delete', 'onclick'=>"return confirmDialog();"));
					echo "</td>";
					$i++;
					echo "</tr>";
	# code...
				}
			}
			?>

		</tbody>
	</table>

	<a href="<?=base_url().'Welcome/form_input';?>" >Registrasi</a>

	<?php  ?>
	<script>
		function confirmDialog() {
			return confirm('Apakah anda yakin akan menghapus data ini?')
		}
	</script>
</body>
</html>